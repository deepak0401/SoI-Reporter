from bs4 import BeautifulSoup
import bs4
import re

input1 = open("inputFilterList.txt", "r")
inputFilterList = []
inputFilterList = input1.readlines()

input2 = open("htmlFullList.txt", "r")
htmlFullList = []
htmlFullList = input2.readlines()

count = 0
countInt = 0
for ctr in range(len(htmlFullList)):
	hfl = '\''+htmlFullList[ctr].strip()+'\''
	for ifl in inputFilterList:
		strIFL1,strIFL2 = ifl.split('#')
		tmpstrIFL2 = strIFL2
		strIFL2 = '\''+strIFL2.strip()+'\''
		
		if hfl == strIFL2:
			htmlFullList[ctr] = strIFL1+"#"+tmpstrIFL2			
			break
		else:
			continue

outfile = 'final_raw_result.txt'
with open(outfile, "w") as out:
	for l in htmlFullList:
		#print(l.strip())
		l=l.strip()+'\n'
		out.write(str(l))
out.close()
