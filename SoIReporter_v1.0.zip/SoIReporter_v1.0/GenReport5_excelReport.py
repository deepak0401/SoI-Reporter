from bs4 import BeautifulSoup
import re
import lxml
import xlsxwriter

wb = xlsxwriter.Workbook('Sonar_Issues_Tab_Report.xlsx')
ws1 = wb.add_worksheet()

f = open("Sonar_Issues_Report.html", "r")
html = f.read()
soup = BeautifulSoup(html,'lxml')

header_format = wb.add_format({'bold': True, 'bg_color': 'orange', 'border': 1, 'align': 'left' ,'valign': 'vcenter'})
header_format.set_text_wrap()

projName_format = wb.add_format({'bold': True, 'bg_color': 'yellow', 'border': 1, 'align': 'left' ,'valign': 'vcenter'})
projName_format.set_text_wrap()

filePath_format = wb.add_format({'bold': True, 'bg_color': 'blue', 'font_color': 'white', 'border': 1, 'align': 'left' ,'valign': 'vcenter'})
filePath_format.set_text_wrap()
#filePath_format.set_font_color('white')

no_format = wb.add_format({'border': 1, 'align': 'left' ,'valign': 'vcenter'})
no_format.set_text_wrap()

ws1.set_column('A:A', 25) #for column A
ws1.set_column('B:O', 12) #for column B:O

table = soup.find("table")
rows = table.findAll("tr")

ws1.write(0,0,'Defect Name',header_format)
ws1.write(0,1,'Defect Age',header_format)
ws1.write(0,2,'Line Number',header_format)
ws1.write(0,3,'BLANK',header_format)
ws1.write(0,4,'Type',header_format)
ws1.write(0,5,'Severity',header_format)
ws1.write(0,6,'Status',header_format)
ws1.write(0,7,'Assignee',header_format)
ws1.write(0,8,'Effort Estimation',header_format)
ws1.merge_range(0, 9, 0, 9+5,'Tags/Resource Name/Comment/Comment Age',header_format)


x = 1  #starting from 2nd row of excel
for tr in rows:
	#tr = tr.strip()
	cols = tr.findAll("td")
	if not cols:
		continue  # when we hit an empty row, we should not print anything to the workbook
	y = 0
	for td in cols:
		#worksheet.write(row, col, string, cell_format)  
		match = re.search(r'^Project Name',td.text)
		if match:
			ws1.merge_range(x, y, x, y+14, td.text, projName_format)
			#ws1.write(x, y, td.text, projName_format)
		else:
			match1 = re.search(r'^File Path',td.text)
			if match1:
				ws1.merge_range(x, y, x, y+14, td.text, filePath_format)
			else:
				ws1.write(x, y, td.text, no_format)
		y = y + 1
	# update the row pointer AFTER a row has been printed
	# this avoids the blank row at the top of your table
	x = x + 1

wb.close()