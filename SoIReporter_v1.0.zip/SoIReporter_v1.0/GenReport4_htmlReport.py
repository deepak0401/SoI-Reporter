from bs4 import BeautifulSoup
import bs4
import re
#import csv

input1 = open("final_raw_result.txt", "r")
final_raw_result = []
final_raw_result = input1.readlines()

#tmpStr = ''
tmpStr = '<html><body><table border="1"><tr>'

for out1 in final_raw_result:
	out1 = out1.strip()
	match = re.search(r'#',out1)
	if match:
		strIFL1,strIFL2 = out1.split('#')
		tmpstrIFL1 = strIFL1
		tmpstrIFL2 = strIFL2
		if tmpstrIFL1 in ('Project Name','File Path','Defect Name'):
			if tmpstrIFL1 in ('Project Name'):
				tmpStr = tmpStr+'</tr>\n<tr><td style="background-color:yellow" colspan="13">'+out1+'</td>'
			elif tmpstrIFL1 in ('File Path'):
				tmpStr = tmpStr+'</tr>\n<tr><td style="background-color:red" colspan="13">'+out1+'</td>'
			else:
				tmpStr = tmpStr+'</tr>\n<tr><td>'+out1+'</td>'
	else:
		tmpStr = tmpStr+'<td>'
		tmpStr = tmpStr+out1+'</td>'

tmpStr = tmpStr + '</tr></table></body></html>'

outfile = 'Sonar_Issues_Report.html'
with open(outfile, "w") as out:
    out.write(tmpStr)
out.close()