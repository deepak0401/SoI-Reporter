from bs4 import BeautifulSoup
#import csv
import bs4
import re

f = open("SonarInput.html", "r")
contents = f.read()
f.close()
inputFilterList = []
inputRuleList = []
inputFilePathList = []
inputDefectList = []
soup = BeautifulSoup(contents,'html.parser')
for element1 in soup.find_all(class_='component-name-parent link-no-underline'):
	x1 = re.sub(r'\n\s*\n', '', element1.text.strip())
	x1 = x1.replace(" ", "")
	ruleSet = x1.encode('utf-8').decode('ascii', 'ignore')
	ruleSet = "Project Name# {}\n".format(ruleSet)
	inputRuleList.append(ruleSet)	
inputFilterList.extend(inputRuleList)

for element2 in soup.find_all(class_='component-name-file link-no-underline'):
	x2 = re.sub(r'\n\s*\n', '', element2.text.strip())
	x2 = x2.replace("  ", "")
	matchUrl = re.compile("(?:[^/]*([a-zA-Z0-9\.\-\_\/]*))")
	m = matchUrl.match(x2)
	m = m.group().encode('utf-8').decode('ascii', 'ignore')
	m = "File Path# {}\n".format(m)
	inputFilePathList.append(m)
inputFilterList.extend(inputFilePathList)


for element3 in soup.find_all(class_='issue-message'):
	x3 = re.sub(r'\n\s*\n', '', element3.text.strip())
	x3 = x3.replace("  ", "")
	defectName = x3.encode('utf-8').decode('ascii', 'ignore')
	defectName = "Defect Name# {}\n".format(defectName)
	inputDefectList.append(defectName)	
inputFilterList.extend(inputDefectList)
	

outfile = 'inputFilterList.txt'
with open(outfile, "w") as out:
	for l in inputFilterList:
		out.write(str(l))
out.close()
f.close()