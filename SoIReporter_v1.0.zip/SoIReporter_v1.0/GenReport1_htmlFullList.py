from bs4 import BeautifulSoup
import bs4
import re

f = open("SonarInput.html", "r+")
contents = f.read()
soup = BeautifulSoup(contents,'html.parser')
for element in soup.find_all(class_='search-navigator-workspace-list'):
	e = re.sub(r'\n\s*\n', '\n', element.text.strip())
	e = e.replace("  ", "")
	infile = e.encode('utf-8').decode('ascii', 'ignore')

outfile = 'htmlFullList.txt'
with open(outfile, "w") as out:
    out.write(infile)
out.close()
f.close()
